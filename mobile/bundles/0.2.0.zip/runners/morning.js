// The morning check (@capacitor/background-runner, run by WorkManager every 30 min once the app has been in the
// background; capacitor.config.ts). It runs in the runner's own JS engine, not the WebView: only fetch, CapacitorKV,
// CapacitorNotifications and a few web APIs. Android loads it from the APK's assets, so a change here needs a new APK
// (app updates cannot replace it): it stays dumb and stable. The app (src/mobile/native/morning.ts) sends it, through
// `configure`, whether he wants it, ready-made JobSearch searches for his filters (src/mobile/engine/runner-config.ts)
// and since when jobs are news; this script only keeps to the window, fetches, adds up total.value and notifies.
// Once a day between 07:45 and 12:00 local time, when the searches count ads published since the later of the last
// notification and the app's last fetch: "N nya jobb som matchar dina filter". Nothing when there are none (the next
// run in the window tries again), nothing after 12:00 (no afternoon surprise).

var KEYS = { config: 'morning.config', since: 'morning.since', notifiedDay: 'morning.notifiedDay' };
var FROM_MINUTE = 7 * 60 + 45;
var UNTIL_MINUTE = 12 * 60;
var NOTIFICATION_ID = 7450;

function read(key) {
  var held = CapacitorKV.get(key);
  return held && typeof held.value === 'string' ? held.value : null;
}

function readTime(key) {
  var value = read(key);
  var t = value === null ? NaN : Date.parse(value);
  return isNaN(t) ? null : t;
}

function pad(n) {
  return n < 10 ? '0' + n : String(n);
}

/** The phone's local day, YYYY-MM-DD. */
function localDay(d) {
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

/** The search with published-after set to the minutes since `since` (JobSearch takes minutes, free of time zones). */
function withSince(url, minutes) {
  if (/[?&]published-after=/.test(url)) return url.replace(/([?&]published-after=)[^&]*/, '$1' + minutes);
  return url + (url.indexOf('?') < 0 ? '?' : '&') + 'published-after=' + minutes;
}

async function count(url) {
  // The runner's fetch needs the method spelled out whenever options are given.
  var res = await fetch(url, { method: 'GET', headers: { accept: 'application/json' } });
  if (res.ok === false || (typeof res.status === 'number' && res.status !== 200)) {
    throw new Error('JobSearch answered ' + res.status);
  }
  var body = await res.json();
  var total = Number(body && body.total && body.total.value);
  return isNaN(total) ? 0 : total;
}

/** What the app sent: { enabled, urls, since }. The later `since` wins, so a notified day is never counted again. */
addEventListener('configure', function (resolve, reject, args) {
  try {
    var urls = args && Array.isArray(args.urls) ? args.urls.filter((u) => typeof u === 'string') : [];
    CapacitorKV.set(KEYS.config, JSON.stringify({ enabled: !!(args && args.enabled === true), urls: urls }));
    var since = args && typeof args.since === 'string' ? Date.parse(args.since) : NaN;
    var held = readTime(KEYS.since);
    if (!isNaN(since) && (held === null || since > held)) CapacitorKV.set(KEYS.since, new Date(since).toISOString());
    resolve();
  } catch (err) {
    console.error('[jk] morning: configure failed: ' + err);
    reject(err);
  }
});

addEventListener('check', async function (resolve) {
  try {
    var now = new Date();
    var config = JSON.parse(read(KEYS.config) || 'null');
    if (!config || config.enabled !== true || !config.urls.length) return resolve({ ran: 'off' });
    var minute = now.getHours() * 60 + now.getMinutes();
    if (minute < FROM_MINUTE || minute >= UNTIL_MINUTE) return resolve({ ran: 'outside the window' });
    var day = localDay(now);
    if (read(KEYS.notifiedDay) === day) return resolve({ ran: 'notified today' });
    var since = readTime(KEYS.since);
    if (since === null) return resolve({ ran: 'no since' });
    var minutes = Math.max(1, Math.ceil((now.getTime() - since) / 60000));
    var total = 0;
    for (var i = 0; i < config.urls.length; i++) total += await count(withSince(config.urls[i], minutes));
    if (total > 0) {
      CapacitorNotifications.schedule([
        {
          id: NOTIFICATION_ID,
          title: 'Jobbkollen',
          body: total === 1 ? '1 nytt jobb som matchar dina filter' : total + ' nya jobb som matchar dina filter',
          scheduleAt: now,
          smallIcon: 'ic_stat_jobbkollen',
          autoCancel: true,
        },
      ]);
      CapacitorKV.set(KEYS.notifiedDay, day);
      CapacitorKV.set(KEYS.since, now.toISOString());
    }
    console.log('[jk] morning: ' + total + ' new since ' + minutes + ' min');
    resolve({ ran: 'checked', total: total });
  } catch (err) {
    // Offline or JobSearch down: the next run in the window tries again.
    console.error('[jk] morning: check failed: ' + err);
    resolve({ ran: 'failed' });
  }
});
